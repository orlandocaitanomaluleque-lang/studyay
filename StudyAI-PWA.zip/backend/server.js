const express=require("express");
const path=require("path");
const bcrypt=require("bcryptjs");
const jwt=require("jsonwebtoken");
const OpenAI=require("openai");
const db=require("./database");

const app=express();
const PORT=process.env.PORT||3000;
const JWT_SECRET=process.env.JWT_SECRET||"development-secret-change-before-production";
const client=process.env.OPENAI_API_KEY?new OpenAI({apiKey:process.env.OPENAI_API_KEY}):null;
const FREE_DAILY_LIMIT=10;

app.use(express.json({limit:"1mb"}));
app.use(express.static(path.join(__dirname,"..","frontend")));

function makeToken(u){return jwt.sign({id:u.id,email:u.email},JWT_SECRET,{expiresIn:"7d"});}
function auth(req,res,next){
 const h=req.headers.authorization||"";
 const t=h.startsWith("Bearer ")?h.slice(7):null;
 if(!t)return res.status(401).json({error:"Não autenticado."});
 try{req.user=jwt.verify(t,JWT_SECRET);next();}
 catch(e){return res.status(401).json({error:"Sessão inválida ou expirada."});}
}
function today(){return new Date().toISOString().slice(0,10);}
function getUsage(id){
 const row=db.prepare("SELECT count FROM usage WHERE user_id=? AND day=?").get(id,today());
 return row?.count||0;
}
function consume(id){
 db.prepare(`INSERT INTO usage(user_id,day,count) VALUES(?,?,1)
 ON CONFLICT(user_id,day) DO UPDATE SET count=count+1`).run(id,today());
}
function user(id){return db.prepare("SELECT id,name,email,plan,created_at FROM users WHERE id=?").get(id);}
function requireAI(){
 if(!client)throw new Error("OPENAI_API_KEY não configurada no servidor.");
}
async function ai(input){
 requireAI();
 const r=await client.responses.create({
   model:"gpt-5.6",
   input:`És o assistente educacional StudyAI. Responde em português claro e adequado para estudantes. Explica sem inventar factos.\n\n${input}`
 });
 return r.output_text||"Não foi possível gerar uma resposta.";
}

app.post("/api/register",async(req,res)=>{
 try{
  const {name,email,password}=req.body;
  if(!name||!email||!password)return res.status(400).json({error:"Preencha todos os campos."});
  if(password.length<8)return res.status(400).json({error:"A palavra-passe deve ter pelo menos 8 caracteres."});
  const e=email.trim().toLowerCase();
  if(db.prepare("SELECT id FROM users WHERE email=?").get(e))
    return res.status(409).json({error:"Este email já está registado."});
  const hash=await bcrypt.hash(password,12);
  const r=db.prepare("INSERT INTO users(name,email,password_hash) VALUES(?,?,?)").run(name.trim(),e,hash);
  const u={id:Number(r.lastInsertRowid),name:name.trim(),email:e,plan:"free"};
  res.status(201).json({token:makeToken(u),user:u});
 }catch(e){console.error(e);res.status(500).json({error:"Erro interno."});}
});

app.post("/api/login",async(req,res)=>{
 try{
  const {email,password}=req.body;
  const u=db.prepare("SELECT * FROM users WHERE email=?").get(String(email||"").trim().toLowerCase());
  if(!u||!(await bcrypt.compare(String(password||""),u.password_hash)))
    return res.status(401).json({error:"Email ou palavra-passe incorretos."});
  const safe={id:u.id,name:u.name,email:u.email,plan:u.plan};
  res.json({token:makeToken(safe),user:safe});
 }catch(e){res.status(500).json({error:"Erro interno."});}
});

app.get("/api/me",auth,(req,res)=>{
 const u=user(req.user.id);
 if(!u)return res.status(404).json({error:"Utilizador não encontrado."});
 res.json({user:u,usage:getUsage(u.id),dailyLimit:u.plan==="premium"?null:FREE_DAILY_LIMIT});
});

app.get("/api/history",auth,(req,res)=>{
 const rows=db.prepare("SELECT id,kind,prompt,answer,created_at FROM history WHERE user_id=? ORDER BY id DESC LIMIT 30").all(req.user.id);
 res.json({history:rows});
});

app.post("/api/ai",auth,async(req,res)=>{
 try{
  const u=user(req.user.id);
  if(u.plan!=="premium"&&getUsage(u.id)>=FREE_DAILY_LIMIT)
    return res.status(429).json({error:"Limite diário gratuito atingido."});
  const prompt=String(req.body.prompt||"").trim();
  if(!prompt||prompt.length>5000)return res.status(400).json({error:"Pergunta inválida."});
  const answer=await ai(prompt);
  consume(u.id);
  db.prepare("INSERT INTO history(user_id,kind,prompt,answer) VALUES(?,?,?,?)").run(u.id,"pergunta",prompt,answer);
  res.json({answer,usage:getUsage(u.id),dailyLimit:u.plan==="premium"?null:FREE_DAILY_LIMIT});
 }catch(e){console.error(e);res.status(500).json({error:e.message||"Erro ao consultar IA."});}
});

app.post("/api/summary",auth,async(req,res)=>{
 try{
  const u=user(req.user.id);
  if(u.plan!=="premium"&&getUsage(u.id)>=FREE_DAILY_LIMIT)return res.status(429).json({error:"Limite diário atingido."});
  const text=String(req.body.text||"").trim();
  if(!text||text.length>12000)return res.status(400).json({error:"Texto inválido."});
  const answer=await ai(`Cria um resumo de estudo, com tópicos principais e conceitos essenciais, do seguinte texto:\n\n${text}`);
  consume(u.id);
  db.prepare("INSERT INTO history(user_id,kind,prompt,answer) VALUES(?,?,?,?)").run(u.id,"resumo",text,answer);
  res.json({answer,usage:getUsage(u.id),dailyLimit:u.plan==="premium"?null:FREE_DAILY_LIMIT});
 }catch(e){res.status(500).json({error:e.message||"Erro ao resumir."});}
});

app.post("/api/quiz",auth,async(req,res)=>{
 try{
  const u=user(req.user.id);
  if(u.plan!=="premium"&&getUsage(u.id)>=FREE_DAILY_LIMIT)return res.status(429).json({error:"Limite diário atingido."});
  const subject=String(req.body.subject||"").trim();
  if(!subject)return res.status(400).json({error:"Indica a matéria."});
  const answer=await ai(`Cria 5 perguntas de escolha múltipla sobre ${subject}. Indica a resposta correta e uma explicação curta. Formata de modo simples para um estudante.`);
  consume(u.id);
  db.prepare("INSERT INTO history(user_id,kind,prompt,answer) VALUES(?,?,?,?)").run(u.id,"quiz",subject,answer);
  res.json({answer,usage:getUsage(u.id),dailyLimit:u.plan==="premium"?null:FREE_DAILY_LIMIT});
 }catch(e){res.status(500).json({error:e.message||"Erro ao criar quiz."});}
});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"..","frontend","index.html")));
app.listen(PORT,()=>console.log(`StudyAI em http://localhost:${PORT}`));
