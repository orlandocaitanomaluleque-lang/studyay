const API="/api";
const save=d=>{localStorage.setItem("studyai_token",d.token);localStorage.setItem("studyai_user",JSON.stringify(d.user));};
const token=()=>localStorage.getItem("studyai_token");
async function api(url,opt={}){
 const h={"Content-Type":"application/json",...(opt.headers||{})};
 if(token())h.Authorization="Bearer "+token();
 const r=await fetch(API+url,{...opt,headers:h}),d=await r.json().catch(()=>({}));
 if(!r.ok)throw new Error(d.error||"Erro.");
 return d;
}
async function registerUser(e){e.preventDefault();try{const d=await api("/register",{method:"POST",body:JSON.stringify({name:name.value,email:email.value,password:password.value})});save(d);location="/dashboard.html"}catch(x){message.className="msg error";message.textContent=x.message}}
async function loginUser(e){e.preventDefault();try{const d=await api("/login",{method:"POST",body:JSON.stringify({email:email.value,password:password.value})});save(d);location="/dashboard.html"}catch(x){message.className="msg error";message.textContent=x.message}}
function logout(){localStorage.clear();location="/login.html"}
async function loadDashboard(){
 if(!token())return location="/login.html";
 try{
  const d=await api("/me");userName.textContent=d.user.name;userEmail.textContent=d.user.email;plan.textContent=d.user.plan==="premium"?"💎 Premium":"🆓 Gratuito";
  usage.textContent=d.dailyLimit===null?`Uso hoje: ${d.usage}`:`Uso hoje: ${d.usage}/${d.dailyLimit}`;
  loadHistory();
 }catch(e){logout()}
}
async function askAI(){
 const q=question.value.trim(); if(!q)return;
 output.textContent="A pensar...";
 try{const d=await api("/ai",{method:"POST",body:JSON.stringify({prompt:q})});output.textContent=d.answer;usage.textContent=d.dailyLimit===null?`Uso hoje: ${d.usage}`:`Uso hoje: ${d.usage}/${d.dailyLimit}`;loadHistory()}catch(e){output.textContent="⚠️ "+e.message}
}
async function summarize(){
 const t=summaryText.value.trim();if(!t)return;
 output.textContent="A criar resumo...";
 try{const d=await api("/summary",{method:"POST",body:JSON.stringify({text:t})});output.textContent=d.answer;usage.textContent=d.dailyLimit===null?`Uso hoje: ${d.usage}`:`Uso hoje: ${d.usage}/${d.dailyLimit}`;loadHistory()}catch(e){output.textContent="⚠️ "+e.message}
}
async function makeQuiz(){
 const s=subject.value.trim();if(!s)return;
 output.textContent="A criar quiz...";
 try{const d=await api("/quiz",{method:"POST",body:JSON.stringify({subject:s})});output.textContent=d.answer;usage.textContent=d.dailyLimit===null?`Uso hoje: ${d.usage}`:`Uso hoje: ${d.usage}/${d.dailyLimit}`;loadHistory()}catch(e){output.textContent="⚠️ "+e.message}
}
async function loadHistory(){
 try{const d=await api("/history");historyBox.innerHTML=d.history.map(x=>`<div style="padding:10px;border-bottom:1px solid #eee"><b>${x.kind}</b><br>${escapeHtml(x.prompt)}</div>`).join("")||"Sem histórico ainda."}catch{}
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}

let deferredInstallPrompt=null;
window.addEventListener("beforeinstallprompt",e=>{
  e.preventDefault();
  deferredInstallPrompt=e;
  const b=document.getElementById("installBtn");
  if(b)b.style.display="inline-block";
});
async function installPWA(){
  if(!deferredInstallPrompt){
    alert("No Chrome no Android, abre o menu ⋮ e procura 'Instalar app' ou 'Adicionar à tela inicial'.");
    return;
  }
  deferredInstallPrompt.prompt();
  await deferredInstallPrompt.userChoice;
  deferredInstallPrompt=null;
  const b=document.getElementById("installBtn");
  if(b)b.style.display="none";
}
